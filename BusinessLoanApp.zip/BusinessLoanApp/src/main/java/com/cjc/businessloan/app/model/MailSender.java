package com.cjc.businessloan.app.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class MailSender 
{
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int mailId;
	private String toEmail; 
	private String fromEmail;
	private String subject;
	private String textMsg;
	@Lob
	private byte[] photo;

}
