package com.cjc.businessloan.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.businessloan.app.model.*;
import com.cjc.businessloan.app.servicei.*;

@CrossOrigin("*")
@RestController
public class ContactController 
{
	
	@Autowired
	ContactServiceI csi;
	
	
//-------------------------------------------------------
	
	//Contact Us Page
	@PostMapping(value="/saveContactUs")
	public String saveContactUs(@RequestBody ContactUs cs)
	{
		csi.saveContactUs(cs);
		return "Save Data Successfully";
	}
	
}
