package com.cjc.businessloan.app.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class PersonalDetails 
{
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int pid;
	private  String name;
	private String address;
	private String email;
	private long mobno;
//	private long adharno;
//	private String panno;
	private String username;
	private String password;

}
