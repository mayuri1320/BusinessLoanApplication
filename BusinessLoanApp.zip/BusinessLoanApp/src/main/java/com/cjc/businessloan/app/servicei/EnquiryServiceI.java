package com.cjc.businessloan.app.servicei;

import java.util.List;

import com.cjc.businessloan.app.model.Enquiry;



public interface EnquiryServiceI
{
	public void saveEnquiry(Enquiry e);
	
	public List<Enquiry> getEnquiry();
	public Enquiry getOneEnquiry(int eid);
	public void deleteEnquiry(int eid);

	public void saveCibilWithEnquires(Enquiry e);

	public Enquiry updateEnquirydata(Enquiry e);

	public List<Enquiry> fetchAllEnquiry();
	
}
