package com.cjc.businessloan.app.servicei;


import com.cjc.businessloan.app.model.ContactUs;


public interface ContactServiceI
{
	
	public void saveContactUs(ContactUs cs);
	
}
