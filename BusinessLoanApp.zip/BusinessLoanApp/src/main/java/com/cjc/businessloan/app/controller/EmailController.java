package com.cjc.businessloan.app.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cjc.businessloan.app.model.MailSender;
import com.cjc.businessloan.app.servicei.EmailServiceI;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;




@CrossOrigin("*")
@RestController
public class EmailController
{
	@Value("${spring.mail.username}")
	String fromEmail;
	
	@Autowired
	EmailServiceI hsi;
	
//-------------------------------------------------------
	
	//Email Sending
	@PostMapping("/sendEmail/{email}")
	public String sendemail(@RequestBody MailSender e,@PathVariable String email)
	{
		
		e.setToEmail(email);
		e.setFromEmail(fromEmail);
		try {
			hsi.sendemail(e,email);
		}catch(Exception e1)
		{
			e1.getStackTrace();
			return "Email not Send";
		}
		return "Email send Successfully";
	}
//-----------------------------------------------

		@PostMapping(value = "/SendAttachFile")
		public String SendAttachmentFile(@RequestParam ("data")String data, @RequestParam("photo") MultipartFile file) throws JsonMappingException, JsonProcessingException
		{
			ObjectMapper om=new ObjectMapper();
			MailSender em=om.readValue(data,MailSender.class);
			
			em.setFromEmail(fromEmail);
			try {
				hsi.SendAttachmentFile(em,file);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "send Attach File Successfully!!!";
			
		}

}
