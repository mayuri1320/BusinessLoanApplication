package com.cjc.businessloan.app.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.businessloan.app.model.DocumentUpload;
import com.cjc.businessloan.app.repository.DocumentRepository;
import com.cjc.businessloan.app.servicei.DocumentsServiceI;

@Service
public class DocumentServiceImpl implements DocumentsServiceI
{

	@Autowired
	
	DocumentRepository dri;
	
	
	@Override
	public DocumentUpload saveDoc(DocumentUpload d) {
		// TODO Auto-generated method stub
		return dri.save(d);
	}
	@Override
	public List<DocumentUpload> getDocuments(int regid) {
		// TODO Auto-generated method stub
		return dri.findByRegid(regid);
	}

	

}
