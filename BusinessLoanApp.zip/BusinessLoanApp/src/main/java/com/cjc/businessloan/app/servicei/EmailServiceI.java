package com.cjc.businessloan.app.servicei;

import org.springframework.web.multipart.MultipartFile;

import com.cjc.businessloan.app.model.MailSender;

public interface EmailServiceI
{

	public void sendemail(MailSender e,String email);

	public void SendAttachmentFile(MailSender em, MultipartFile file);
	
}
