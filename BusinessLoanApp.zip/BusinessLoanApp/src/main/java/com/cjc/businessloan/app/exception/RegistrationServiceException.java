package com.cjc.businessloan.app.exception;

public class RegistrationServiceException extends Exception {
	
	
	private static final long serialVersionUID = 1L;

	public  RegistrationServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	

}