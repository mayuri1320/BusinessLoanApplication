package com.cjc.businessloan.app.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.RestController;

import com.cjc.businessloan.app.model.Enquiry;
import com.cjc.businessloan.app.servicei.EnquiryServiceI;

@CrossOrigin("*")
@RestController
public class EnquiryController 
{
	
	@Autowired
	EnquiryServiceI esi;
	

//-------------------------------------------------------
	@PostMapping(value="/saveEnquiry")
	public String saveEnquiry(@RequestBody Enquiry e)
	{
		esi.saveEnquiry(e);
		return "Save Data Successfully";
	}
	
	@GetMapping(value="/getEnquiry")
	public List<Enquiry> getEnquiry()
	{
		return esi.getEnquiry();
	}
	@GetMapping(value="/getOneEnquiry/{eid}")
	public Enquiry getOneEnquiry(@RequestParam int eid)
	{
		return esi.getOneEnquiry(eid);
	}
	@DeleteMapping("/deleteEnquiry/{eid}")
	public String deleteEnquiry(@RequestParam int eid) 
	{
		 esi.deleteEnquiry(eid);
		 return "Data Deleted Successfully";
	}
	@PostMapping("/saveEnquiry/cibil")
	public List<Enquiry> getAllEnquiriesWithCibil(@RequestBody Enquiry e)
	{
		esi.saveCibilWithEnquires(e);
		List<Enquiry> allEnquiry=esi.fetchAllEnquiry();
		return allEnquiry;
	}
	
	
	@PutMapping("/editEnquiry")
	public String editdata(@RequestBody Enquiry e )
	{
		Enquiry e1=esi.updateEnquirydata(e);
		return e1.getEid()+ "update Enquiry successfully";
	}
}
//----------------------------------------------------------------------------
	