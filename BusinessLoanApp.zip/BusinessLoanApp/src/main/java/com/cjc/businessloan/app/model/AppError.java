package com.cjc.businessloan.app.model;

public class AppError {
	
	private int errorcode;
	private String studentmessage;
	public AppError(int errorcode, String studentmessage) {
		super();
		this.errorcode = errorcode;
		this.studentmessage = studentmessage;
	}
	public AppError() {
		super();
		// TODO Auto-generated constructor stub
	}

}
