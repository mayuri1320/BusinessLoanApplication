package com.cjc.businessloan.app.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cjc.businessloan.app.exception.RegistrationServiceException;
import com.cjc.businessloan.app.model.AppError;

@ControllerAdvice
public class ExceptionAdvice {
	
	@ExceptionHandler(RegistrationServiceException.class)
	public ResponseEntity<AppError> mapStudentError(RegistrationServiceException se){
		
		System.out.println("3 in exceptionadvice");
		AppError serror=new AppError(HttpStatus.OK.value(),se.getMessage());
		
		return new ResponseEntity<AppError>(serror ,HttpStatus.OK);
		
	}

}
