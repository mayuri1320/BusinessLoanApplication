package com.cjc.businessloan.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.businessloan.app.model.DocumentUpload;

@Repository
public interface DocumentRepository extends JpaRepository<DocumentUpload, Integer>
{

	List<DocumentUpload> findByRegid(int regid);
	
}
