package com.cjc.businessloan.app.serviceimpl;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cjc.businessloan.app.model.MailSender;
import com.cjc.businessloan.app.repository.MailSenderRepository;
import com.cjc.businessloan.app.servicei.EmailServiceI;



@Service
public class EmailServiceImpl implements EmailServiceI
{
	
	@Autowired
	MailSenderRepository mri;
	@Autowired 
	JavaMailSender sender;
	
	
	//Mail Sending 
	public void sendemail(MailSender e,String email) 
	{
		SimpleMailMessage sms = new SimpleMailMessage();
		sms.setTo(e.getToEmail());
		sms.setFrom(e.getFromEmail());
		sms.setSubject("This Form is Accepted");
		sms.setText("welcome to Business Loan Application");
		sender.send(sms);
		mri.save(e);
	}

	
	@Override
	public void SendAttachmentFile(MailSender em, MultipartFile file)
	{
		MimeMessage message=sender.createMimeMessage();
		
		try {
			MimeMessageHelper helper=new MimeMessageHelper(message, true);
			helper.setTo(em.getToEmail());
			helper.setFrom(em.getFromEmail());
			helper.setSubject(em.getSubject());
			helper.setText(em.getTextMsg());
			helper.addAttachment(file.getOriginalFilename(), file);
			
			sender.send(message);
			
		} 
		catch (MessagingException e)
		{
			e.printStackTrace();
		}
	}
}



