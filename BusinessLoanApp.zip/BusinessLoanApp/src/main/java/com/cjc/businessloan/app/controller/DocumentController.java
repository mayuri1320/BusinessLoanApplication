package com.cjc.businessloan.app.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cjc.businessloan.app.model.DocumentUpload;
import com.cjc.businessloan.app.servicei.DocumentsServiceI;
import com.fasterxml.jackson.databind.ObjectMapper;
@CrossOrigin("*")
@RestController
public class DocumentController {
	
	@Autowired
	DocumentsServiceI service;
	
	@PostMapping(value = "/saveDoc", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public DocumentUpload saveDoc(@RequestPart(value = "pancard") MultipartFile f1,
			@RequestPart(value = "adharcard") MultipartFile f2,
			@RequestPart(value = "bankstatement") MultipartFile f3,			
			@RequestPart(value = "balancesheet") MultipartFile f4,		
			@RequestPart(value = "companypan") MultipartFile f5,
			@RequestPart(value = "incometax") MultipartFile f6,			
			@RequestPart("doc") String doc) throws IOException

	{
		DocumentUpload d = new DocumentUpload();		
		
		d.setPancard(f1.getBytes());
		d.setAdharcard(f2.getBytes());
		d.setBankstatement(f3.getBytes());		
		d.setBalancesheet(f4.getBytes());
		d.setCompanypan(f5.getBytes());
		d.setIncometax(f6.getBytes());
		
		ObjectMapper om = new ObjectMapper();
		DocumentUpload ds = om.readValue(doc, DocumentUpload.class);
		d.setRegid(ds.getRegid());
   				
		return  service.saveDoc(d);
	}	
	
	@GetMapping("/getdocument/{regid}")
	public List<DocumentUpload> getDocuments(@PathVariable int regid)
	{
		 return service.getDocuments(regid);
	
	}
	
	
	
	
	

}

