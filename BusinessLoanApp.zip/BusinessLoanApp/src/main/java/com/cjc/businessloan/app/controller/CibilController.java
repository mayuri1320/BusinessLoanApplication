package com.cjc.businessloan.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.businessloan.app.model.CibilCheck;
import com.cjc.businessloan.app.servicei.CibilServiceI;

@CrossOrigin("*")
@RestController
public class CibilController 
{
	
	@Autowired
	CibilServiceI csi;
	
	
		//Cibil Check
	
	@PostMapping("/postCibilScore")
	public String saveCibilScore(@RequestBody CibilCheck cb)
	{
		CibilCheck cscore=csi.saveCibilScore(cb);
		return "Saved In Database";
	}
	
	@GetMapping("/getCibilScore")
	public List<CibilCheck> getCibilScore()
	{
		return csi.getCibilScore();
		
	}

	

}
