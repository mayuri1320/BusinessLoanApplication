package com.cjc.businessloan.app.servicei;

import java.util.List;

import com.cjc.businessloan.app.model.ContactUs;
import com.cjc.businessloan.app.model.DocumentUpload;
import com.cjc.businessloan.app.model.Enquiry;
import com.cjc.businessloan.app.model.MailSender;
import com.cjc.businessloan.app.model.Registration;

public interface HomeServiceI
{
	public void saveEnquiry(Enquiry e);
	
	
	public void saveContactUs(ContactUs cs);
	public Registration saveRegDetails(Registration reg);
	public DocumentUpload savedocumnet(DocumentUpload upload);
	public List<DocumentUpload> showDocument();
	public void sendemail(MailSender e,String email);
	public Enquiry getCibilScore(String panno,Enquiry e);

	public DocumentUpload showOneDocument(int regid);
}
