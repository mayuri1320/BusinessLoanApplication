package com.cjc.businessloan.app.serviceimpl;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cjc.businessloan.app.model.ContactUs;
import com.cjc.businessloan.app.repository.ContactRepository;
import com.cjc.businessloan.app.servicei.ContactServiceI;


@Service
public class ContactServiceImpl implements ContactServiceI
{
	@Autowired
	ContactRepository cri;
	
	
	
	public void saveContactUs(ContactUs cs) {
		cri.save(cs);
		
	}	

	

}
