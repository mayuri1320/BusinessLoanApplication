package com.cjc.businessloan.app.servicei;

import java.util.List;

import com.cjc.businessloan.app.model.Registration;

public interface RegistrationServiceI
{	
	public Registration saveRegDetails(Registration reg);

	public Iterable<Registration> viewData();

	public Registration saveRedata(Registration rr);

	public List<Registration> verifiedForm(String status);

	public Registration sanctionDetails(int rid, Registration re);
	
}
