package com.cjc.businessloan.app.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.businessloan.app.model.Registration;
import com.cjc.businessloan.app.servicei.RegistrationServiceI;



@CrossOrigin("*")
@RestController
public class RegistrationController 
{
	private final Logger logger=LoggerFactory.getLogger(this.getClass()) ;
	
	@Autowired
	RegistrationServiceI hsi;
	
	@RequestMapping("/")
	public String preload()
	{
		return "welcome";
	}
//-------------------------------------------------------
	
	//Registration Page
	
	@PostMapping("/saveRegistrationDetails")
	public Registration saveRegDetails(@RequestBody Registration reg)
	{
		reg.setStatus("Register");
		return hsi.saveRegDetails(reg);
	}
//----------------------------------------------------------------------
	@GetMapping("/getregsitereddata")
	Iterable<Registration> getData()
	{
		return hsi.viewData();
	}
//-----------------------------------------------------------
	@PutMapping("/FormVerified/{rid}")
	public Registration saveverifier(@PathVariable int rid, @RequestBody Registration rr)
	{		
		rr.setStatus("verified");
	return hsi.saveRedata(rr);
			
	}
	
	@PutMapping("/FormRejected/{rid}")
	public Registration saverejected(@PathVariable int rid,@RequestBody Registration rr)
	{
		rr.setStatus("Rejected");
	   return hsi.saveRedata(rr);
	}
	
	@GetMapping("/getverified/{status}")
	public List<Registration> verified(@PathVariable String status)
	{
		return hsi.verifiedForm(status);
	}
	
	
	@PutMapping("/sanction/{rid}")
	public Registration sanction(@PathVariable int rid, @RequestBody Registration re)
	{
		return hsi.sanctionDetails(rid,re);
	}
	

	
	





}
