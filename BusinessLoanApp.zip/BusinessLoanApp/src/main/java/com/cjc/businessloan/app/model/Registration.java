package com.cjc.businessloan.app.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Registration 
{
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int rid;
	private String status;
	@OneToOne(cascade = CascadeType.ALL)
	private PersonalDetails pd;
	@OneToOne(cascade = CascadeType.ALL)
	private BankDetails bd;
	@OneToOne(cascade = CascadeType.ALL)
	private GarenterDetails gd;
	@OneToOne(cascade = CascadeType.ALL)
	private Sanction sanction;
	@OneToOne(cascade = CascadeType.ALL)
	private Disbursement disbutment;

	
	

}
