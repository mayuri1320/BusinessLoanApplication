package com.cjc.businessloan.app.serviceimpl;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cjc.businessloan.app.model.Enquiry;
import com.cjc.businessloan.app.repository.EnquiryRepository;
import com.cjc.businessloan.app.servicei.EnquiryServiceI;



@Service
public class EnquiryServiceImpl implements EnquiryServiceI
{
	@Autowired
	EnquiryRepository hri;
	
	
	public void saveEnquiry(Enquiry e)
	{
		hri.save(e);
	}
	public List<Enquiry> getEnquiry() {
		
		return hri.findAll();
	}
	
	public Enquiry getOneEnquiry(int eid)
	{
		return hri.findByEid(eid);
	}
	
	public void deleteEnquiry(int eid) 
	{
		hri.deleteById(eid);		
	}
	@Override
	public void saveCibilWithEnquires(Enquiry e)
	{
		Random r=new Random();
		//e.setCibilScore(r.nextInt(750-650)+650);
		//repositoy.save(e);
		
		int CibilScore=r.nextInt(850-650)+650;
		e.setCscore(CibilScore);
		
		if(CibilScore<700)
		{
			e.setStatus("rejected");
		}
		else if(CibilScore>=700 && CibilScore<725)
		{
			e.setStatus("Pending");
		}
		else if(CibilScore>=725)
		{
			e.setStatus("Accepted");
		}
		hri.save(e);
		
		
	}
		
		
		
	@Override
	public Enquiry updateEnquirydata(Enquiry e) {
		
		return hri.save(e);
	}
	@Override
	public List<Enquiry> fetchAllEnquiry() {
		return hri.findAll();
	}


	

}
