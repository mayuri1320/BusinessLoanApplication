package com.cjc.businessloan.app.servicei;

import java.util.List;

import com.cjc.businessloan.app.model.DocumentUpload;


public interface DocumentsServiceI
{

	DocumentUpload saveDoc(DocumentUpload d);

	List<DocumentUpload> getDocuments(int regid);
	
}
