package com.cjc.businessloan.app.serviceimpl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cjc.businessloan.app.model.CibilCheck;
import com.cjc.businessloan.app.repository.CibilRepository;
import com.cjc.businessloan.app.servicei.CibilServiceI;

import java.util.Random;



@Service
public class CibilServiceImpl implements CibilServiceI
{
	@Autowired
	CibilRepository cbri;
	
	@Override
	public CibilCheck saveCibilScore(CibilCheck cb) {

		Random random=new Random();
		
		cb.setCibilScore(random.nextInt(900-600)+600);
		CibilCheck cscore=cbri.save(cb);
		return cscore;

	}



	@Override
	public List<CibilCheck> getCibilScore() {
		
		return cbri.findAll();
	}	

	

}
