package com.cjc.businessloan.app.serviceimpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.businessloan.app.model.Registration;
import com.cjc.businessloan.app.repository.RegistrationRepository;
import com.cjc.businessloan.app.servicei.RegistrationServiceI;


@Service
public class RegistrationServiceImpl implements RegistrationServiceI
{
	private final Logger logger=LoggerFactory.getLogger(this.getClass()) ;
	
	@Autowired
	RegistrationRepository rri;

	public Registration saveRegDetails(Registration reg) 
	{
		return rri.save(reg);		
	}

	@Override
	public Iterable<Registration> viewData()
	{
		return rri.findAll();
	}

	@Override
	public Registration saveRedata(Registration rr) 
	{		
		return rri.save(rr);
	}

	@Override
	public List<Registration> verifiedForm(String status) 
	{
		return rri.findAllByStatus(status);
	}

	@Override
	public Registration sanctionDetails(int rid, Registration re) 
	{		
		Registration r= rri.findAllByRid(rid);		
		
		return rri.save(r);
	}
	

}
