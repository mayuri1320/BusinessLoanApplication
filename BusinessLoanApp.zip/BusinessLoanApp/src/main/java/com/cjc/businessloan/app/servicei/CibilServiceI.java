package com.cjc.businessloan.app.servicei;

import java.util.List;

import com.cjc.businessloan.app.model.CibilCheck;
import com.cjc.businessloan.app.model.Enquiry;


public interface CibilServiceI
{
	


	public CibilCheck saveCibilScore(CibilCheck cb);

	public List<CibilCheck> getCibilScore();

	
}
