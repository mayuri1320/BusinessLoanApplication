package com.cjc.businessloan.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.businessloan.app.model.CibilCheck;
import com.cjc.businessloan.app.model.ContactUs;
@Repository
public interface CibilRepository extends JpaRepository<CibilCheck, Integer>
{

}
