package com.cjc.businessloan.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.businessloan.app.model.Registration;

@Repository
public interface RegistrationRepository extends JpaRepository<Registration, Integer>
{

	List<Registration> findAllByStatus(String status);

	Registration findAllByRid(int rid);

}
